﻿namespace prjCode
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLengte = new System.Windows.Forms.TextBox();
            this.txtPols = new System.Windows.Forms.TextBox();
            this.btnBerekenVraag2 = new System.Windows.Forms.Button();
            this.lblOptimaalGewicht = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblDeler = new System.Windows.Forms.Label();
            this.lblQuotient = new System.Windows.Forms.Label();
            this.lblDeeltal = new System.Windows.Forms.Label();
            this.txtDeler = new System.Windows.Forms.TextBox();
            this.btnBerekenVraag3 = new System.Windows.Forms.Button();
            this.txtDeeltal = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtBe = new System.Windows.Forms.TextBox();
            this.txtBanknummer = new System.Windows.Forms.TextBox();
            this.txtControle = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "lengte in cm";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "polsomtrek in cm";
            // 
            // txtLengte
            // 
            this.txtLengte.Location = new System.Drawing.Point(141, 27);
            this.txtLengte.Name = "txtLengte";
            this.txtLengte.Size = new System.Drawing.Size(75, 20);
            this.txtLengte.TabIndex = 2;
            // 
            // txtPols
            // 
            this.txtPols.Location = new System.Drawing.Point(141, 50);
            this.txtPols.Name = "txtPols";
            this.txtPols.Size = new System.Drawing.Size(75, 20);
            this.txtPols.TabIndex = 3;
            // 
            // btnBerekenVraag2
            // 
            this.btnBerekenVraag2.Location = new System.Drawing.Point(27, 79);
            this.btnBerekenVraag2.Name = "btnBerekenVraag2";
            this.btnBerekenVraag2.Size = new System.Drawing.Size(75, 23);
            this.btnBerekenVraag2.TabIndex = 4;
            this.btnBerekenVraag2.Text = "Berekenen";
            this.btnBerekenVraag2.UseVisualStyleBackColor = true;
            this.btnBerekenVraag2.Click += new System.EventHandler(this.btnBerekenVraag2_Click);
            // 
            // lblOptimaalGewicht
            // 
            this.lblOptimaalGewicht.AutoSize = true;
            this.lblOptimaalGewicht.Location = new System.Drawing.Point(108, 84);
            this.lblOptimaalGewicht.Name = "lblOptimaalGewicht";
            this.lblOptimaalGewicht.Size = new System.Drawing.Size(35, 13);
            this.lblOptimaalGewicht.TabIndex = 3;
            this.lblOptimaalGewicht.Text = "label1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblOptimaalGewicht);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnBerekenVraag2);
            this.groupBox1.Controls.Add(this.txtLengte);
            this.groupBox1.Controls.Add(this.txtPols);
            this.groupBox1.Location = new System.Drawing.Point(440, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(246, 138);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vraag 2";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblDeler);
            this.groupBox2.Controls.Add(this.lblQuotient);
            this.groupBox2.Controls.Add(this.lblDeeltal);
            this.groupBox2.Controls.Add(this.txtDeler);
            this.groupBox2.Controls.Add(this.btnBerekenVraag3);
            this.groupBox2.Controls.Add(this.txtDeeltal);
            this.groupBox2.Location = new System.Drawing.Point(440, 180);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(246, 129);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Vraag 3";
            // 
            // lblDeler
            // 
            this.lblDeler.AutoSize = true;
            this.lblDeler.Location = new System.Drawing.Point(22, 48);
            this.lblDeler.Name = "lblDeler";
            this.lblDeler.Size = new System.Drawing.Size(32, 13);
            this.lblDeler.TabIndex = 1;
            this.lblDeler.Text = "Deler";
            // 
            // lblQuotient
            // 
            this.lblQuotient.AutoSize = true;
            this.lblQuotient.Location = new System.Drawing.Point(147, 84);
            this.lblQuotient.Name = "lblQuotient";
            this.lblQuotient.Size = new System.Drawing.Size(35, 13);
            this.lblQuotient.TabIndex = 3;
            this.lblQuotient.Text = "label1";
            // 
            // lblDeeltal
            // 
            this.lblDeeltal.AutoSize = true;
            this.lblDeeltal.Location = new System.Drawing.Point(22, 22);
            this.lblDeeltal.Name = "lblDeeltal";
            this.lblDeeltal.Size = new System.Drawing.Size(40, 13);
            this.lblDeeltal.TabIndex = 1;
            this.lblDeeltal.Text = "Deeltal";
            // 
            // txtDeler
            // 
            this.txtDeler.Location = new System.Drawing.Point(75, 45);
            this.txtDeler.Name = "txtDeler";
            this.txtDeler.Size = new System.Drawing.Size(100, 20);
            this.txtDeler.TabIndex = 6;
            // 
            // btnBerekenVraag3
            // 
            this.btnBerekenVraag3.Location = new System.Drawing.Point(25, 79);
            this.btnBerekenVraag3.Name = "btnBerekenVraag3";
            this.btnBerekenVraag3.Size = new System.Drawing.Size(116, 23);
            this.btnBerekenVraag3.TabIndex = 7;
            this.btnBerekenVraag3.Text = "Berekenen Quotiënt";
            this.btnBerekenVraag3.UseVisualStyleBackColor = true;
            this.btnBerekenVraag3.Click += new System.EventHandler(this.btnBerekenVraag3_Click);
            // 
            // txtDeeltal
            // 
            this.txtDeeltal.Location = new System.Drawing.Point(75, 19);
            this.txtDeeltal.Name = "txtDeeltal";
            this.txtDeeltal.Size = new System.Drawing.Size(100, 20);
            this.txtDeeltal.TabIndex = 5;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtControle);
            this.groupBox3.Controls.Add(this.txtBanknummer);
            this.groupBox3.Controls.Add(this.txtBe);
            this.groupBox3.Location = new System.Drawing.Point(23, 24);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(231, 70);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Vraag 1";
            // 
            // txtBe
            // 
            this.txtBe.Location = new System.Drawing.Point(31, 27);
            this.txtBe.Name = "txtBe";
            this.txtBe.Size = new System.Drawing.Size(36, 20);
            this.txtBe.TabIndex = 0;
            this.txtBe.Text = "BE 0";
            this.txtBe.TextChanged += new System.EventHandler(this.txtBe_TextChanged);
            // 
            // txtBanknummer
            // 
            this.txtBanknummer.Location = new System.Drawing.Point(73, 27);
            this.txtBanknummer.MaxLength = 7;
            this.txtBanknummer.Name = "txtBanknummer";
            this.txtBanknummer.Size = new System.Drawing.Size(54, 20);
            this.txtBanknummer.TabIndex = 0;
            this.txtBanknummer.TextChanged += new System.EventHandler(this.txtBanknummer_TextChanged);
            // 
            // txtControle
            // 
            this.txtControle.Location = new System.Drawing.Point(133, 27);
            this.txtControle.MaxLength = 2;
            this.txtControle.Name = "txtControle";
            this.txtControle.Size = new System.Drawing.Size(37, 20);
            this.txtControle.TabIndex = 1;
            this.txtControle.TextChanged += new System.EventHandler(this.txtControle_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLengte;
        private System.Windows.Forms.TextBox txtPols;
        private System.Windows.Forms.Button btnBerekenVraag2;
        private System.Windows.Forms.Label lblOptimaalGewicht;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblDeeltal;
        private System.Windows.Forms.TextBox txtDeeltal;
        private System.Windows.Forms.Label lblDeler;
        private System.Windows.Forms.TextBox txtDeler;
        private System.Windows.Forms.Label lblQuotient;
        private System.Windows.Forms.Button btnBerekenVraag3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtBe;
        private System.Windows.Forms.TextBox txtBanknummer;
        private System.Windows.Forms.TextBox txtControle;
    }
}

