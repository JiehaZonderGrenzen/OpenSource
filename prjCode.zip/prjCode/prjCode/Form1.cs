﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjCode
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region Vraag 1:

        private void txtBe_TextChanged(object sender, EventArgs e)
        {
            txtBe.Text = "BE 0";
            txtBanknummer.Focus();
        }

        private void txtBanknummer_TextChanged(object sender, EventArgs e)
        {
            if (txtBanknummer.Text.Length == 7)
            {
                txtControle.Focus();
            }
        }

        private void txtControle_TextChanged(object sender, EventArgs e)
        {
            if (txtControle.Text.Length == 2 && txtBanknummer.Text.Length == 7)
            {
                try
                {
                    int banknummer = Convert.ToInt32(txtBanknummer.Text);
                    int controlenummer = Convert.ToInt32(txtControle.Text);

                    if (BerekenenVraag1(banknummer, controlenummer) == true)
                    {
                        MessageBox.Show("Geldig");
                    }
                    else
                    {
                        MessageBox.Show("Ongeldig");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }

        }

        private bool BerekenenVraag1(int banknummer, int controlenummer)
        {
            if (Convert.ToInt32(banknummer % 97) == controlenummer)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion Einde Vraag 1.


        #region Vraag 2:
        private void btnBerekenVraag2_Click(object sender, EventArgs e)
        {
            try
            {
                double L = Convert.ToInt32(txtLengte.Text);
                double P = Convert.ToInt32(txtPols.Text);

                lblOptimaalGewicht.Text = BerekenenVraag2(L, P).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private double BerekenenVraag2(double L, double P)
        {

            double M = (L + 4 * P - 100) / 2;

            return M;
        }
        #endregion Einde Vraag 2.





        #region Vraag 3:

        private void btnBerekenVraag3_Click(object sender, EventArgs e)
        {
            try
            {
                int deeltal = Convert.ToInt32(txtDeeltal.Text);
                int deler = Convert.ToInt32(txtDeler.Text);

                lblQuotient.Text = BerekenenVraag3(deeltal, deler).ToString();
            }
            catch
            {
                MessageBox.Show("Wie deelt door nul is een snul!");
            }
        }

        private double BerekenenVraag3(int deeltal, int deler)
        {

            int quotient = deeltal / deler;

            return quotient;
        }


        #endregion Einde Vraag 3.



    }
}
